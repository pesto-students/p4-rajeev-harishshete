import "./styles.css";
import "./App.css";
// import React, { useState } from "react";
import URLShortner from "./URLShortner";
import BackgroudAnimate from "./BackgroudAnimate";
import LinkResult from "./LinkResult";
import { useState } from "react";

function App() {
  const[inputValue,setInputValue] = useState();
  
  return (
    <>
      <div className="container">
        <URLShortner setInputValue={setInputValue} />
        <BackgroudAnimate />
        <LinkResult inputValue ={inputValue} />    
      </div>
    </>
  );

  // return <h1>HI</h1>



}

export default App;
