import React, { useState, useEffect } from "react";

function ToDoItem(props) {
  //const [itemName, setItemName] = useState("");
  // useEffect(() => {
  //   // const checkbox = document.getElementById("todoCheckBox");
  //   // const li = document.getElementById("todoItem");

  //   // if (checkbox.checked === true) {
  //   //   li.style.textDecoration = "line-through";
  //   // }

  //   const checkbox = document.getElementsByClassName("form-check-input");
  //   const todoItem = document.getElementsByClassName("bg-light border");
  //   checkbox[0].addEventListener("change", (event) => {
  //     if (event.currentTarget.checked) {
  //       //alert("checked");
  //       todoItem[0].style.textDecoration = "line-through";
  //     } else {
  //       //alert("not checked");
  //       todoItem[0].style.textDecoration = "none";
  //     }
  //   });
  // });
  const [state, setState] = useState({ textDecoration: "none" });

  function handleCheckBoxCLick(event) {
    if (event.currentTarget.checked) {
      setState({ textDecoration: "line-through" });
    } else {
      setState({ textDecoration: "none" });
    }
  }

  return (
    <>
      <li className="p-2 bg-light border" style={state}>
        <input
          id="todoCheckBox"
          className="form-check-input mt-0"
          type="checkbox"
          value=""
          aria-label="Checkbox for following text input"
          onClick={handleCheckBoxCLick}
        />
        {props.value}
      </li>
    </>
  );
}

export default ToDoItem;
