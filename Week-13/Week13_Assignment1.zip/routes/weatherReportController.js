const express = require('express');
const { route } = require('express/lib/router');
const router = express.Router();
const request = require('request');
const axios = require('axios');
// const fetch = require("node-fetch")
 

// :city is Request parameter
router.get('/:city', async (req, res) => {
    console.log("Received Get Request '/weatherReport' ");

    var url = `https://api.openweathermap.org/data/2.5/weather?q=${req.params.city}&appid=ad19684355f1dcdf747fa51fd5f4a75e`;

    request(url, (error, response, body) => {
        console.log(url);
        if (error) {
            res.send("Error" + error);
        } else {
            res.send(body);
        }
    });

})


router.post("/", async (req, res) => {
    console.log()
    try {
        const myArray = req.body.city;
        let urls = [];
        for (const val of myArray) {
            urls.push(`https://api.openweathermap.org/data/2.5/weather?q=${val}&appid=ad19684355f1dcdf747fa51fd5f4a75e`);
        }
        // map every url to the promise of the fetch
        let requests = urls.map((url) => axios.get(url));
        let data;
        try {
            const res = await Promise.all(requests);
            data = res.map((res) => res.data);
            console.log(data.flat());
        } catch {
            throw Error("Promise failed");
        }
        return res.send(data);
    } catch (err) {
        console.log(err);
    } finally {
        console.log("finallyStatements");
    }
});


module.exports = router; 