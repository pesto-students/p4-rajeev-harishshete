const express = require('express');
const app = express();

app.use(express.json());

const weatherReportController = require('./routes/weatherReportController');
app.use('/weatherReport', weatherReportController)

app.listen(9000, ()=>{
    console.log("server Started...");
})
