const fs = require("fs/promises");

async function main() {
    console.log(await fs.access("node_modules"));
    // const data = await fs.access("node_modules");
    // console.log (data);
}
main ();