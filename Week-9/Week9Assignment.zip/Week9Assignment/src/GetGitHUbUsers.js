import { useState, useEffect } from "react";

function getRepos(username = 'arfatsalman') {
    console.log(`getRepos: called with ${username}`);
    return fetch(`https://api.github.com/users/${username}/repos`,
        {
            headers: { Authorization: `token ${process.env.REACT_APP_GITHUB_TOKEN}` },
        }).then((res) => res.join());
}

function App() {

    const [username, setUsername] = useState('');
    const [data, setData] = useState([]);

    async function handler(username) { }

    useEffect(() => {
        console.log('effect');

        async function handler() {
            const data = await getRepos();
            if(Array.isArray(data)){
                setData(data);
            }
        }

        handler();
    }, [username]);
}

return (
    <>
        <input value={username} onChange={(event) => { setUsername(event.target.value) }} />
        <h2>Getting Repos for {username}</h2>
        <ul>
            {
                data.map((el) => {
                    return <li key={el.name}> {el.name} </li>
                })
            }
        </ul>
    </>
);