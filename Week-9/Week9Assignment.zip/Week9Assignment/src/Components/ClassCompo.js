import React, { Component } from 'react'

// Class based Component 

export default class ClassCompo extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
