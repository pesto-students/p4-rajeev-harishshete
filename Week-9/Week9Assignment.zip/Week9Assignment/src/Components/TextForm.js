import React, { useState } from 'react'

export default function TextForm(props) {

    const handleOnClick = () => {
        console.log("OnClicked Was clicked");
        const newtext = text.toUpperCase();
        setText(newtext);
    }

    const handleLoOnClick = () => {
        const newtext = text.toLocaleLowerCase();
        setText(newtext);
    }

    const handleOnChange = (event) => {
        console.log("OnChange Was clicked");
        setText(event.target.value);
    }

    const handleMailExtractor = () => {
        //const arr = text.split(" ");
        text.split(" ").forEach(element => {
            if (element.includes('@') && element.endsWith('.com')) {
                setMail_Ids(mail_Ids + element);
            }
        });
    }

    const [text, setText] = useState('Enter Text Here');//Initial value of text variable
    const [mail_Ids, setMail_Ids] = useState('');

    return (
        <>
            <div>
                <h1>{props.heading}</h1>
                <div className="mb-3">
                    <textarea className="form-control" id="myBox" rows="8" value={text} onChange={handleOnChange} ></textarea>
                </div>
                <button className="btn btn-primary" onClick={handleOnClick}>To Upper Case</button>
                <button className="btn btn-primary mx-2" onClick={handleLoOnClick}>To Lower Case</button>
                <button className="btn btn-primary mx-2" onClick={handleMailExtractor}>Extract Mail ids</button>

            </div>
            <div className="container">
                <h1 className='my-2'>Text Summary</h1>
                <p>
                    {text.split(" ").length} Words and {text.length} Characters
                </p>
                <h1>Preview</h1>
                <p>{text}</p>
                <h2>Below Mail Id/s Found</h2>
                <p>{mail_Ids}</p>
            </div>
        </>
    )
}
