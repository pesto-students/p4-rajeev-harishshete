//const helloWorld = <h1>Hello {name}!</h1>; OR
const helloWorld = React.createElement("h1", null, "Hello Harish"); // Constant component
//const helloWorld = React.createElement('element-Name',props,'element-body');


/*
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);*/