const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    firstname:{
        type: String,
        required: true
    },
    laststname:{
        type: String,
        required: true
    },
    dob:{
        type: Date
    },
    mailId:{
        type: String,
        required: true
    },   
    phonenumber:{
        type: Number
    },
    country:{
        type: String
    },
    city:{
        type: String
    },
    username:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    
}, {
    timestamps: { createdAt: true, updatedAt: false }
});

module.exports = mongoose.model('User', userSchema);
