const mongoose = require('mongoose');

const incomeSchema = new mongoose.Schema({
    sourcename:{
        type: String,
        required: true
    },
    year:{
        type: String,
        required: true
    },
    month:{
        type: String,
        required: true
    },
    date:{
        type: String
    },   
    ammount:{
        type: Number,
        required: true
    }
    
}, {
    timestamps: { createdAt: true, updatedAt: false }
});

module.exports = mongoose.model('Income', incomeSchema);
