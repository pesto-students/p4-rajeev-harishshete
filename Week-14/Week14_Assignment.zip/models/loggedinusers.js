var loggedinUser = "";

function setLoggedinUser(user)
{
    loggedinUser = user;
}

function getLoggedinUser(){
    return loggedinUser;
}

module.exports.getLoggedinUser = getLoggedinUser;
module.exports.setLoggedinUser = setLoggedinUser;