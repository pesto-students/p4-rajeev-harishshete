const mongoose = require('mongoose');

const investmentSchema = new mongoose.Schema({
    investmentname:{
        type: String,
        required: true
    },
    year:{
        type: String,
        required: true
    },
    month:{
        type: String,
        required: true
    },
    date:{
        type: String
    },   
    ammount:{
        type: Number,
        required: true
    }
    
}, {
    timestamps: { createdAt: true, updatedAt: false }
});

module.exports = mongoose.model('Investment', investmentSchema);
