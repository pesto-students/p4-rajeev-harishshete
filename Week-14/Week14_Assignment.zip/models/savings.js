const mongoose = require('mongoose');

const savingsSchema = new mongoose.Schema({    
    year:{
        type: String,
        required: true
    },
    month:{
        type: String,
        required: true
    },    
    ammount:{
        type: Number,
        required: true
    }
    
}, {
    timestamps: { createdAt: true, updatedAt: false }
});

module.exports = mongoose.model('Savings', savingsSchema);
