const express = require('express');
const { Query } = require('mongoose');
const router = express.Router();
const Income = require('../models/income');
const Users = require('../models/users');
const mailSender = require('../service/mailSender');
const loggedinUser = require('../models/loggedinusers');

//insert Income details
router.post('/', async (req,res)=>{
    console.log("Received request for investment Insert");

    const income = new Income({
        sourcename: req.body.sourcename,
        year: req.body.year,
        month: req.body.month,
        date: req.body.date,
        ammount: req.body.ammount
    });

    try {
        const resultSet = income.save();
        if(resultSet){
           
            const {mailId} = await Users.findOne({"username":loggedinUser.getLoggedinUser()},{mailId:1, _id:0})
            mailSender.sendMail(
                'Income Insert Notification :: Wealth Portfolio',
                `${req.body.sourcename} added to the Income, log in for detailed info`,
                mailId
            )

            res.end(`income for ${req.body.sourcename} insrted in Database`);
        }
    } catch (error) {
        res.end("Error" + error);
    }

});

//update Income details
router.patch('/', async (req,res)=>{    
    
    try {
        const updatedIncome = {};
    // Investment.updateOne({"investmentname":req.body.investmentname}, $set:{});

    if(req.body.newsourcename){
        updatedIncome.sourcename = req.body.newsourcename;
    }
    
    if(req.body.year){
        updatedIncome.year = req.body.year;
    }

    if(req.body.month){
        updatedIncome.month = req.body.month;
    }

    if(req.body.date){
        updatedIncome.date = req.body.date;
    }
    
    if(req.body.ammount){
        updatedIncome.ammount=req.body.ammount;
    }

    // await is must here 
    const resultSet =  await Income.findOneAndUpdate({"sourcename":req.body.sourcename}, {$set:updatedIncome},{new: true});        
    res.json(resultSet);

    } catch (error) {
        console.log(error);
        res.send("Error received " + error);
        
    }
    
});


//Retrieve Income details
router.get('/', async (req,res)=>{

    try {    
        const rs = await Income.find();
        res.json(rs)
    } catch (error) {
        res.end()
    }

});


//Delete Income details
router.delete('/', async (req,res)=>{
    
    try {
        if( await Income.deleteOne({"sourcename":req.body.sourcename}) )
        {
            res.end(`${req.body.sourcename} deleted from Income`);
        }
    } catch (error) {
        res.end("Error Received \n " + error)
    }
});


module.exports = router;

