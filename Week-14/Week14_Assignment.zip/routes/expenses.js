const express = require('express');
const { Query } = require('mongoose');
const router = express.Router();
const Expense = require('../models/expenses');
const Users = require('../models/users');
const loggedinUser = require('../models/loggedinusers');
const mailSender = require('../service/mailSender');


//insert Expense details
router.post('/', async (req,res)=>{
    console.log("Received request for investment Insert");

    const expense = new Expense({
        expensename: req.body.expensename,
        year: req.body.year,
        month: req.body.month,
        date: req.body.date,
        ammount: req.body.ammount
    });

    try {
        const resultSet = expense.save();
        if(resultSet){

            const {mailId} = await Users.findOne({"username":loggedinUser.getLoggedinUser()},{mailId:1, _id:0})
            mailSender.sendMail(
                'Expense Insert Notification :: Wealth Portfolio',
                `${req.body.expensename} added to the expenses, log in for detailed info`,
                mailId
            )
            
            res.end(`Expense for ${req.body.expensename} insrted in Database`);
        }
    } catch (error) {
        res.end("Error" + error);
    }

});

// update Expense details
router.patch('/', async (req,res)=>{    
    
    try {
        const updatedExpense = {};
    // Investment.updateOne({"investmentname":req.body.investmentname}, $set:{});

    if(req.body.newexpensename ){
        updatedExpense.expensename = req.body.newexpensename;
    }
    
    if(req.body.year){
        updatedExpense.year = req.body.year;
    }

    if(req.body.month){
        updatedExpense.month = req.body.month;
    }

    if(req.body.date){
        updatedExpense.date = req.body.date;
    }
    
    if(req.body.ammount){
        updatedExpense.ammount=req.body.ammount;
    }

    // await is must here 
    
    const resultSet =  await Expense.findOneAndUpdate({"expensename":req.body.expensename}, {$set:updatedExpense},{new: true});        
    res.json(resultSet);

    } catch (error) {
        console.log(error);
        res.send("Error received " + error);
        
    }
    
});

//Retrieve Expense details
router.get('/', async (req,res)=>{
    console.log("Logged in user: " + loggedinUser.getLoggedinUser());

try {
    const rs = await Expense.find();
    res.json(rs)
} catch (error) {
    res.end("  Error Received " + error);
}

});


//Delete Expense details
router.delete('/', async (req,res)=>{
    
    try {
        if( await Expense.deleteOne({"expensename":req.body.expensename}) )
        {
            res.end(`${req.body.expensename} deleted from Expense`);
        }
    } catch (error) {
        res.end("Error Received \n " + error)
    }
});

module.exports = router;

