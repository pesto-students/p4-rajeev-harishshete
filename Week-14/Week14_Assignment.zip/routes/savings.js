const express = require('express');
const { Query } = require('mongoose');
const savings = require('../models/savings');
const router = express.Router();
const Savings = require('../models/savings');


//insert Savings details
router.post('/', async (req,res)=>{
    console.log("Received request for investment Insert");

    const savings = new Savings({
        year: req.body.year,
        month: req.body.month,
        ammount: req.body.ammount
    });

    try {
        const resultSet = savings.save();
        if(resultSet){
            res.end( `Saving Inserted for ${req.body.month},${req.body.year}`);
        }
    } catch (error) {
        res.end("Error" + error);
    }

});

//update Savings details
// year and Month must be provided for updating
router.patch('/', async (req,res)=>{    
    
    try {
        const updatedSavings = {};
    // Investment.updateOne({"investmentname":req.body.investmentname}, $set:{});
    
    if(req.body.newyear){
        updatedSavings.year = req.body.newyear;
    }

    if(req.body.newmonth){
        updatedSavings.month = req.body.newmonth;
    }

    if(req.body.ammount){
        updatedSavings.ammount=req.body.ammount;
    }
    
    // await is must here 
    const resultSet =  await Savings.findOneAndUpdate({"year":req.body.year, "month": req.body.month}, {$set:updatedSavings},{new: true});        
    res.json(resultSet);

    } catch (error) {
        console.log(error);
        res.send("Error received " + error);
        
    }
    
});


//Retrieve Savings details
router.get('/', async (req,res)=>{

try {
    const rs = await Savings.find();
    res.json(rs)
} catch (error) {
    res.end("Error Received : " + error) 
}

});


//Delete Savings details
router.delete('/', async (req,res)=>{
    
    try {
        if( await savings.deleteOne({"year":req.body.year, "month": req.body.month}))
        {
            res.end(`Savings deleted for ${req.body.month},${req.body.year}`);
        }
    } catch (error) {
        res.end("Error Received \n " + error)
    }
});


module.exports = router;