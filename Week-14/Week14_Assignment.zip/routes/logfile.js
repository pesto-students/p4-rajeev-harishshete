var name = "Harish";
var lastname = "Shete";

module.exports.name = name;
module.exports.lastname = lastname;


