const express = require('express');
const { Query } = require('mongoose');
const router = express.Router();
const Users = require('../models/users');
const loggedinUser = require('../models/loggedinusers');


//signup
router.post('/', async (req, res) => {
    console.log("Received request for new Signup");

    Users.findOne(
        { "username": req.body.username },
        (err, user) => {
            if (err) {
                // console.log(err);   
                res.end("Error" + err);
            } else {
                if (user) {
                    res.end(`username ${req.body.username} already exist enter different one`);
                }
            }

        });

    const users = new Users({
        firstname: req.body.firstname,
        laststname: req.body.laststname,
        dob: req.body.dob,
        mailId: req.body.mailId,
        phonenumber: req.body.phonenumber,
        country: req.body.country,
        city: req.body.city,
        username: req.body.username,
        password: req.body.password
    })

    try {
        const a1 = await users.save();
        if (a1)
            res.end(`New User ${req.body.username} Added to the Data Base`);
    } catch (error) {
        res.end("Eror" + error);
    }


});

//login
router.get('/', async (req, res) => {
    console.log("Received request for Login");
    Users.findOne({ $and: [{ "username": req.body.username }, { "password": req.body.password }] },
        (err, user) => {
            if(err){
                res.end("Error" + err);
            }
            else{
                if(user)
                {

                    loggedinUser.setLoggedinUser(req.body.username);                    
                    res.send("Valid User");

                }
                else{
                    res.end("Invalid username or password");
                }
            }
        });
});

module.exports.router = router;