const express = require('express');
const { Query } = require('mongoose');
const router = express.Router();
const Investment = require('../models/investments');


//insert investment details
router.post('/', async (req,res)=>{
    console.log("Received request for investment Insert");

    const investment = new Investment({
        investmentname: req.body.investmentname,
        year: req.body.year,
        month: req.body.month,
        date: req.body.date,
        ammount: req.body.ammount
    });

    try {
        const resultSet = investment.save();
        if(resultSet){
            res.end( req.body.investmentname + "Investment inserted in the table");
        }
    } catch (error) {
        res.end("Error" + error);
    }

});

//update investment details
router.patch('/', async (req,res)=>{    
    
    try {
        const updatedInvestment = {};
    // Investment.updateOne({"investmentname":req.body.investmentname}, $set:{});

    if(req.body.newinvestmentname){
        updatedInvestment.investmentname = req.body.newinvestmentname;
    }
    
    if(req.body.year){
        updatedInvestment.year = req.body.year;
    }

    if(req.body.month){
        updatedInvestment.month = req.body.month;
    }

    if(req.body.date){
        updatedInvestment.date = req.body.date;
    }
    
    if(req.body.ammount){
        updatedInvestment.ammount=req.body.ammount;
    }

    // await is must here 
    const resultSet =  await Investment.findOneAndUpdate({"investmentname":req.body.investmentname}, {$set:updatedInvestment},{new: true});        
    res.json(resultSet);

    } catch (error) {
        console.log(error);
        res.send("Error received " + error);
        
    }
    
});


//Retrieve investment details
router.get('/', async (req,res)=>{

try {
    const rs = await Investment.find();
    res.json(rs)
} catch (error) {
    res.end("   Error Received " + error);
}

});


//Delete investment details
router.delete('/', async (req,res)=>{
    
    try {
        if( await Investment.deleteOne({"investmentname":req.body.investmentname}) )
        {
            res.end(`${req.body.investmentname} deleted from Investments`);
        }
    } catch (error) {
        res.end("Error Received \n " + error)
    }
});



module.exports = router;




/*
video> documentt = {"tech": "Java", "age":22 }
{ tech: 'Java', age: 22 }
video> db.Programmers.findOneAndUpdate({"name":"harish"},  {$set: documentt})
{
  _id: ObjectId("63664edb36dc2a93348181d0"),
  name: 'harish',
  tech: 'Ruby',
  age: 22
}

*/