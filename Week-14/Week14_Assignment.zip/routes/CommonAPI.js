const express = require('express');
const { Query } = require('mongoose');
const router = express.Router();
const expenses = require('../models/expenses');
const expenses = require('../models/expenses');
const savings = require('../models/savings');


//get income, Expense and savings
router.get('/', async (req,res)=>{});

//insert income and Expense
router.get('/', async (req,res)=>{});

//upload invoice
router.post('/', async (req,res)=>{});


module.exports = router;



