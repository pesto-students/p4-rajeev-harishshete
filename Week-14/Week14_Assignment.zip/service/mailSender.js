var nodemailer = require('nodemailer');


var transporter = {};
var mailOptions = {};
   
function setTransporter(){
    transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'harishshete430@gmail.com',
          pass: 'xvrfdzfjtuqtdnzt'
        }
    });    
}

function setmailOptions(){
    
    mailOptions = {
        from: 'harishshete430@gmail.com',
        to: 'harishshete430@gmail.com',
        subject: 'Important Notification from Wealth Portfolio',
        text: 'That was easy!'
    };

}


function sendMail(subject='Important Notification From Wealth Portfolio',mailBody, receiver='harishshete430@gmail.com'){
    
    transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'harishshete430@gmail.com',
          pass: 'xvrfdzfjtuqtdnzt'
        }
    }); 

    mailOptions = {
        from: 'harishshete430@gmail.com',
        to: receiver,
        subject: subject,
        text: mailBody
    };


    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
    });
}


module.exports.sendMail = sendMail;





