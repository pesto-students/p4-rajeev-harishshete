import { createStore } from "redux";

// Reducer Function
function Store(Counter = 0, action) {
  switch (action.type) {
    case "INC":
      return (Counter = Counter + 1);
    case "RESET":
      return (Counter = 0);
    default:
      return Counter;
  }
}

// Created Store
const CounterStore = createStore(Store);

export default CounterStore;
