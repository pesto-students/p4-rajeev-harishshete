import "./styles.css";
import { connect } from "react-redux";

function App(props) {
  const { Counter, dispatch } = props;

  // Action Creator
  function Increment() {
    dispatch({ type: "INC" });
  }

  // Action Creator
  function Decrement() {
    dispatch({ type: "RESET" });
  }

  return (
    <div className="App">
      <h1>Step Counter</h1>
      <p>Youi have walked {Counter} Today!</p>
      <button className="btn btn-primary" onClick={Increment}>
        Add Step
      </button>
      <button className="btn btn-secondary" onClick={Decrement}>
        Reset Steps
      </button>
    </div>
  );
}

const ConnectedApp = connect((state) => {
  return {
    Counter: state
  };
})(App);

export default ConnectedApp;
