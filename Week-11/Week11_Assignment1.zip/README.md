# Plain React Room with Lightswitch

This is a simple React app with one piece of state.

---

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
