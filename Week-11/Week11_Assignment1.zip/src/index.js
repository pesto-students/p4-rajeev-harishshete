import React from "react";
import ReactDOM from "react-dom";
import LRStore from "./LightRoomStore";
import { connect, Provider } from "react-redux";
// import App from "./LightRoomStore";
import "./index.css";

class Room extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLightOn: true
    };
  }

  flipLight = () => {
    this.props.dispatch({ type: "TOGGLE" });
    this.setState({
      isLightOn: LRStore.getState()
    });
  };

  render() {
    const lightedness = this.state.isLightOn ? "lit" : "dark";
    return (
      <div className={`room ${lightedness}`}>
        the room is {lightedness}
        <br />
        <button onClick={this.flipLight}>flip</button>
      </div>
    );
  }
}

const ConnectedRoom = connect(null, null)(Room);

ReactDOM.render(
  <Provider store={LRStore}>
    <ConnectedRoom />
  </Provider>,
  document.getElementById("root")
);
