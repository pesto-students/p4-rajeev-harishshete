import { createStore } from "redux";

//Reducer Function
function LightRoomStore(LightState = true, action) {
  switch (action.type) {
    case "TOGGLE":
      return (LightState = !LightState);
    default:
      return LightState;
  }
}

const LRStore = createStore(LightRoomStore);

LRStore.subscribe(() => {
  console.log("State Changed " + LRStore.getState());
});

export default LRStore;

// export default LRStore;
